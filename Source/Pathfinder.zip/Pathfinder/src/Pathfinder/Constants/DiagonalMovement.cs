﻿
namespace Pathfinder.Constants
{
    public enum DiagonalMovement : byte
    {
        Never = 0,
        OnlyWhenNoObstacles = 1,
        Always = 2,
        
    }
}
