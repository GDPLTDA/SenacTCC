﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSAProblem.GeneticAlgorithm
{
    public class Coordinate
    {
        public double X;
        public double Y;
    }
}
